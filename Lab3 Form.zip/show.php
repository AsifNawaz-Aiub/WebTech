<html>
<body>


Your name is : <?php echo $_POST["name"]; ?> <br>
Your email is : <?php echo $_POST["email"]; ?> <br>
Your birthdate is : <?php echo $_POST["birthdate"];?> <br>
Your gender is : <?php echo $_POST["gender"];?> <br>
Your degree is : <?php echo $_POST["degree"];?> <br>
Your blood group is : <?php echo $_POST["group"];?> <br>



</body>
</html>