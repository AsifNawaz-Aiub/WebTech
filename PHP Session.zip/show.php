<?php
// Start the session
session_start();
?>

<html>
<body>


Your name is : <?php echo $_POST["name"]; ?> <br>
Your email is : <?php echo $_POST["email"]; ?> <br>




<form action="showall.php" method="POST">
<?php 
$_SESSION["bd"] = $_POST["birthdate"];
$_SESSION["gender"] = $_POST["gender"];
$_SESSION["degree"] =  $_POST["degree"];
$_SESSION["group"] = $_POST["group"];
?>
<input type="submit" value="Show All" name="submit">
</form> 




</body>
</html>