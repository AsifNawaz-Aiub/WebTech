<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Echo session variables that were set on previous page
echo "Your Birthday is " . $_SESSION["bd"] . ".<br>";
echo "Your Gender is " . $_SESSION["gender"] . ".<br>";
echo "Your Degree is " . $_SESSION["degree"] . ".<br>";
echo "Your  Group is " . $_SESSION["group"] . ".<br>";

?>

</body>
</html>