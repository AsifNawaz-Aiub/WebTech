<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>Log In</title>
</head>
<body>

<form action="<?= htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
UserName <br>
<input type="text" name="username" >
<br>
Password <br>
<input type="text" name="password">

<br><br>

<input type="submit" name="login" value="Login">
 
</form>  


</body>
</html>

<?php
if(isset($_POST['login']))
{
	$con=mysqli_connect("localhost","root","","web");
	if(!$con)
	{
		die("Connection Error: ".mysqli_connect_error()."<br/>");
	}
	//Retrieve Data

	$password=$_POST['password'];
	$username=$_POST['username'];
	$sql="SELECT * FROM info WHERE email='$username' AND password='$password'";
	
	$result=mysqli_query($con,$sql);
	
	if(mysqli_num_rows($result)>0)
	{
		$row=mysqli_fetch_array($result);
		$_SESSION['name']=$row['Name'];
		
		header("Location:user.php");
	}
	else
	{
		echo "No data found.<br/>";
	}

	
mysqli_close($con);		
}

?>