<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>

<title>Main PAGE</title>

<style>

header {
  background-color: green;
  text-align: Left;
  font-size: 35px;
}
.h {
  background-color: green;
  text-align: right;
   padding: 15px;
  font-size: 15px;
}

</style>

</head>
<body>

<form>
<header>X Company

<div class='h'>
<a href="Login.php">Log In</a>
<a href="REGISTRATION.php">REGISRATION</a> 
<a href="HOME.html">HOME</a>
</div>
</header>

<h3>WELCOME TO X COMPANY</h3>

</form>  


</body>
</html>