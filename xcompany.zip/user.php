<?php
session_start();
$name=$_SESSION['name'];

?>
<!DOCTYPE html>
<html>
<head>
<title>USER</title>
<link rel="stylesheet" type="text/css" href="style.css">
<Style>
header {
  background-color: green;
  padding: 10px;
  text-align: Left;
  font-size: 35px;
  color: white;
}
#asas {
  background-color: green;
  padding: 5px;
  text-align: right;
  font-size: 15px;
  color: white;
}

nav {
  float: left;
  width: 30%;
  height: 300px; /* only for demonstration, should be removed */
  background: #ccc;
  padding: 5px;
}

/* Style the list inside the menu */
nav ul {
	 background: #ccc;
  list-style-type: none;
  padding: 0;
}

article {
  float: center;
  padding: 5px;
  width: 70%;
  background-color: #f1f1f1;
  height: 300px; /* only for demonstration, should be removed */
}

/* Clear floats after the columns */
section:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the footer */
footer {
  background-color: #777;
  padding: 5px;
  text-align: center;
  color: white;
}

</Style>
</head>
<body>

<header>
  <h2>Xcompany</h2>
  <h5 id='asas'><a href="#">LOGOUT</a></h5>
</header>



<section>
  <nav>
  <h3>Account</h3>
    <ul>
      <li><a href="#">DASHBOARD</a></li>
      <li><a href="edit.php">EDIT PROFILE</a></li>
      <li><a href="view.php">VIEW PROFILE</a></li>
	  <li><a href="cp.php">CHANGE PASSWORD</a></li>
	  <li><a href="add.php">Add Product</a></li>
	  
    </ul>
  </nav>
  
  <article>
    <h1>WELCOME <?php echo $name ?></h1>
    </article>
</section>


<footer>
  <p>Copyright</p>
</footer>

<form>

 
</form>  


</body>
</html>
