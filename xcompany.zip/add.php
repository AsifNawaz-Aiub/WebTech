<?php
session_start();

?>

<html>
	<head>
		<title>Add Product</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<style>
		p{
		background-color: green;
  padding: 35px;
  text-align: Left;
  font-size: 35px;
  color: white;
		}
		</style>
	</head>
	<body>
	 <p>X Company</p>
		<fieldset align="center">
			<legend>Add Product</legend>
			<form action="<?= htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
				<table align="center">
					<tr>
						<td>Product Name</td>
						<td><input type="text" name="pname" placeholder="Name of the Product"/></td>
					</tr>
					<tr>
						<td>Buying Price</td>
						<td><input type="text" name="bprice" /></td>
					</tr>
						<tr>
						<td>Selling Price</td>
						<td><input type="text" name="sprice" /></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="submit" name="submit" value="Submit"/></td>
					</tr>
				</table>
			</form>
		</fieldset>
			<fieldset align="center">
			<legend>Display</legend>
			<form action="<?= htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
				<table align="center">
					<tr>
						<td>Product Name</td>
						<td>Profit</td>
					</tr>
					<tr>
						<td> <?php echo ""; ?></td>
						<td><?php echo ""; ?></td>
						<td><?php echo ""; ?></td>
					</tr>
					
					<tr>
						<td></td>
						<td><input type="submit" name="display" value="display"/></td>
					</tr>
				</table>
			</form>
		</fieldset>

	</body>
</html>



<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web";

try {
    
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
	// set the PDO error mode to exception

  
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
$sql = "INSERT INTO product (ProductName,BuyingPrice,SellingPrice) VALUES ('".$_POST['pname']."',".$_POST['bprice'].",".$_POST['sprice'].")";
    
	// use exec() because no results are returned
    
	$conn->exec($sql);
    echo "New record created successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;



?>



